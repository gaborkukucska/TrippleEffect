"""Test Package - Python_CLI_with_Pytest_Tests"""


def __version__():
    """Returns the version of this test package."""
    return "0.1.0"
