#!/usr/bin/env python3
"""CLI Application - Python_CLI_with_Pytest_Tests

A minimal but functional command-line interface application.
Usage: python main.py [command] [options]

Commands:
    help     Show this help message and exit
    version  Display the current version of CLI app
    
Examples:
    $ python main.py --help
    $ python main.py -h
"""


def __version__():
    """Returns the version of this application."""
    return "0.1.0"
